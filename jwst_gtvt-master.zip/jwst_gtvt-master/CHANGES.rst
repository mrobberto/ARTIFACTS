0.2.0
=====

- Adding support for the python >= 3.7
- Adding pysiaf library. pysiaf pulls the v3 reference angle for the GTVT/MTVT.
- Small print/output statements updates.
- Updating repo to follow INS community software standards.
- Switched the CI from travis to Github Actions

0.1.2 
=====

- verbose argument is available via command line. Users can select to suppress output from GTVT/MTVT.